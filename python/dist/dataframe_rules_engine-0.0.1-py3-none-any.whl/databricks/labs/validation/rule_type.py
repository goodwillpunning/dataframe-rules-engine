
class RuleType:

    ValidateExpr = "expr"
    ValidateBounds = "bounds"
    ValidateNumerics = "validNumerics"
    ValidateStrings = "validStrings"
    ValidateDateTime = "validDateTime"
    ValidateComplex = "complex"
